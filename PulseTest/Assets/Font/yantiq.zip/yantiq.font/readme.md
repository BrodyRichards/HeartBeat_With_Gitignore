Yantiq v0.1
===========
Script, handwritten font, cute (maybe)

---

Aydi Rainkarnichi (c) 2016  
https://twitter.com/aydiriku  
https://www.facebook.com/rainkarnichi  

---

Download here:
https://github.com/rainkarnichi  
https://fontlibrary.org/en/member/rainkarnichi  
http://www.dafont.com/aydi-rainkarnichi.d5676  
http://www.fontspace.com/rainkarnichi  

---

**Yantiq** typeface - *Open Font License*